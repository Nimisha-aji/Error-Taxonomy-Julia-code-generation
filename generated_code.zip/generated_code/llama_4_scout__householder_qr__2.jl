function householder_qr(A)
    m, n = size(A)
    Q = Matrix{eltype(A)}(I(m))
    R = copy(A)

    for j in 1:min(m, n)
        x = R[j:m, j]
        e1 = zeros(m - j + 1)
        e1[1] = 1
        if norm(x) == 0
            continue
        end
        v = sign(x[1]) * norm(x) * e1 + x
        v /= norm(v)
        H = I(m) - 2 * v * v'
        H = H[j:m, j:m]
        R[j:m, :] = H * R[j:m, :]
        Q[:, j:m] = Q[:, j:m] * H
    end

    Q = Q[:, 1:m]
    R = triu(R)

    return (Q, R)
end