function weighted_jacobi(A, b, x0, omega, tol, max_iter)
    n = length(b)
    x = copy(x0)
    for _ in 1:max_iter
        r = b - A * x
        if norm(r) < tol
            return x
        end
        D = diag(A)
        x .= x .+ omega .* (r ./ D)
    end
    return x
end