function householder_qr(A)
    m, n = size(A)
    Q = Matrix{eltype(A)}(I(m))
    R = copy(A)

    for j in 1:min(m, n)
        x = R[j:m, j]
        e1 = zeros(length(x))
        e1[1] = 1
        v = sign(x[1]) * norm(x) * e1 + x
        v ./= norm(v)
        H = I(m) - 2 * v * v'
        H = H[j:m, j:m]
        R[j:m, j:n] = H * R[j:m, j:n]
        Q[:, j:m] = Q[:, j:m] * H
    end

    Q = Q[:, 1:m]
    R = triu(R)

    return (Q, R)
end